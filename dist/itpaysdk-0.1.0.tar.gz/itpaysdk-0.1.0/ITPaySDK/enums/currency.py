from enum import Enum


class Currency(Enum):
    RUB = 'RUB'
    USD = 'USD'
    EUR = 'EUR'
