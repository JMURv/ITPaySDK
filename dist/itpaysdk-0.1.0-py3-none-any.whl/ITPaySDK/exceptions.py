
class ITPayStatusException(Exception):
    def init(self, message):
        super().init(message)
